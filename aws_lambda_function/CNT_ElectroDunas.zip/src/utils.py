import boto3

s3 = boto3.client('s3')

def remove_confirm(logger,source_bucket):
    # Elimina el archivo de confirmación de carga de datos
    response = s3.list_objects_v2(Bucket=source_bucket)
    for item in response.get('Contents', []):
        key = item['Key']
        if key.endswith('.confirm'):
            # Borrar el archivo
            s3.delete_object(Bucket=source_bucket, Key=key)
            logger.info(f"status: terminado - Archivo {key} eliminado de {source_bucket}")