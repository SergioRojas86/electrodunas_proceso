import boto3
import json
import csv
import pandas as pd
import io
from datetime import datetime
import time

s3 = boto3.client('s3')

def check_economic_filed_file(logger,source_bucket,cleaning_bucket,clean_folder):
    
    prefix_file = 'sector_economico_clientes.xlsx'
    response_source = s3.list_objects_v2(Bucket=source_bucket, Prefix=prefix_file)
    
    if 'Contents' in response_source:
        copy_source = {'Bucket': source_bucket, 'Key': prefix_file}
        dest = f'{clean_folder}/{prefix_file}'
        s3.copy(copy_source, cleaning_bucket, dest)
        
        logger.info(f'status: ejecutando - se ha actualizado el archivo: {cleaning_bucket}/{clean_folder}/{prefix_file}')
        
        # Eliminar el archivo del bucket origen
        s3.delete_object(Bucket=source_bucket, Key=prefix_file)
        return 1
    else:
        prefix_file_clean = f'{clean_folder}/{prefix_file}'
        response_cleaning = s3.list_objects_v2(Bucket=cleaning_bucket, Prefix=prefix_file_clean)
        if 'Contents' in response_cleaning:
            logger.info(f'status: ejecutando - el catalogo ya existe en {cleaning_bucket}/{clean_folder}/{prefix_file}')
            return 1
        else:
            return 0
            
        
def get_number(file, preffix='DATOSCLIENTE'):
    # obtenemos el número del cliente desde su archivo
    number = file.split(preffix)[1].split('.')[0]
    return number

def arrange_folder(logger,backup_bucket,source_bucket,cleaning_bucket,clean_folder,execution_date,preffix='data/DATOSCLIENTE'):
    
    # Listar objetos en el bucket
    response = s3.list_objects_v2(Bucket=source_bucket, Prefix=preffix)
    
    logger.info('status: ejecutando - Comienza la creación de carpetas por año ')
    
    # tomar los archivos csv y crear por cada cliente un archivo por año
    if 'Contents' in response:
        for obj in response['Contents']:
            if obj['Key'].endswith('.csv'):
                file = obj['Key']
                number = get_number(file)
                
                # Leer el contenido del archivo CSV
                response_object = s3.get_object(Bucket=source_bucket, Key=file)
                csv_content = response_object['Body'].read().decode('utf-8')
                df = pd.read_csv(io.StringIO(csv_content))
                
                # Se agrega un campo de cliente para poder cruzar con la base sector_economico_clientes.xlsx mas adelante
                df['Cliente'] = 'Cliente ' + number
                df['Fecha'] = pd.to_datetime(df['Fecha'])
                df['Año'] = df['Fecha'].dt.year
                
                groups = df.groupby(['Año','Cliente'])
                
                for (year, client), data_groups in groups:
                    file_name = f"{year}_{client.replace(' ', '_')}.csv"
                    year_folder = f"{clean_folder}/{year}"
                    
                    # Convertir dataframe a CSV
                    csv_buffer = data_groups.to_csv(index=False, encoding='ISO-8859-1')
                    
                    # Ruta completa del archivo en S3
                    s3_key = f"{year_folder}/{file_name}"
                    
                    # Subir el archivo a S3
                    s3.put_object(Bucket=cleaning_bucket, Key=s3_key, Body=csv_buffer)
    
    logger.info(f'status: ejecutando - Finalizó la creación de carpetas en {cleaning_bucket}/{clean_folder}')        
            
    if 'Contents' in response:        
        # mover la carpeta de data al bucket de backup
        for obj in response['Contents']:
            source_key = obj['Key']
            destination_key = source_key.replace('data/', f'data_{execution_date}/')
            
            # Copiar el archivo al bucket destino
            copy_source = {'Bucket': source_bucket, 'Key': source_key}
            s3.copy(copy_source, backup_bucket, destination_key)
            
            # Eliminar el archivo del bucket origen
            s3.delete_object(Bucket=source_bucket, Key=source_key)
    
        logger.info(f'status: ejecutando - Archivos copiado de {source_bucket} a {backup_bucket}')
        logger.info(f'status: ejecutando - Archivo {source_bucket}/data eliminado del bucket fuente')