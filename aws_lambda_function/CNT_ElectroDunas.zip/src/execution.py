import boto3
import json
import csv
import io
from datetime import datetime
import time
from src.read_and_list_s3 import read_csv_files_log_s3 

s3 = boto3.client('s3')

def execution(logger,instance_id,param):
    
    logger.info(f"status: ejecutando - la ejecución inicia")
    
    data_to_send = json.dumps(param)
    
    command = f"python3 /home/ec2-user/electrodunas_proceso/main.py '{data_to_send}'"  # Reemplaza con la ruta correcta de tu script
    
    # Crear un cliente de SSM
    ssm_client = boto3.client('ssm')
    
    # Ejecutar el comando en la instancia EC2
    response = ssm_client.send_command(
        InstanceIds=[instance_id],
        DocumentName="AWS-RunShellScript",
        Parameters={'commands': [command]}
    )

    # Obtener ID del comando ejecutado
    command_id = response['Command']['CommandId']

    while True:
        try:
            invocation_response = ssm_client.get_command_invocation(
                CommandId=command_id,
                InstanceId=instance_id
            )
            status = invocation_response['Status']
            
            if status in ["Success", "Failed", "Cancelled", "TimedOut"]:
                break
            
        except ssm_client.exceptions.InvocationDoesNotExist:
            logger.info("status: ejecutando - El resultado del comando aún no está disponible, esperando...")
            time.sleep(5)  # Espera 5 segundos antes de volver a intentar
    
    # Imprimir la salida dependiendo del estado del comando
    if status == 'Success':
        logger.info(f'stdout: {invocation_response['StandardOutputContent']}')
    else:
        logger.info(f'stderr: {invocation_response['StandardErrorContent']}')
    

def execution_process(logger, instance_id, folders_info, log_bucket, log_file, cleaning_bucket, clean_folder, stage_folder):
    
    logger.info(f"status: ejecutando - Inicia pipeline")
    
    list_executed_files=[]
    files_to_execute=[]
    
    # Listar objetos en el bucket de log
    response_log = s3.list_objects_v2(Bucket=log_bucket)
    
    # parametros para la ejecución del proceso en la instancia
    param = {'log_bucket':log_bucket, 
            'log_file':log_file, 
            'cleaning_bucket':cleaning_bucket, 
            'clean_folder':clean_folder, 
            'stage_folder':stage_folder}
    
    # revisar si hay un log con las ejecuciones anteriores
    flag=0
    for obj in response_log['Contents']:
        if obj['Key'] == log_file:
            flag=1
    
    if flag == 0:    
        logger.info(f"status: ejecutando - No hay ejecuciones anteriores")
        # necesita ser ejecutadas las fechas existentes en folders info, momento cero del proceso (primera ejecución)
        files_to_execute = folders_info
        
        # Agregar los archivos a ejecutar en los parametros de ejecución
        param['files_to_execute'] = files_to_execute
        
        ##### ejecución del proceso
        execution(logger,instance_id,param)
        
    else:
        for obj in response_log.get('Contents', []):
            if obj['Key'] == log_file:
                # leer log de los archivos ya ejecutados
                list_executed_files = read_csv_files_log_s3(log_bucket, log_file)
                logger.info(f'status: ejecutando - list_executed_files: {list_executed_files}')
                
        executed_dates = [item[:2] for item in list_executed_files]
        folder_dates = [item[:2] for item in folders_info]
        
        # Revisar que archivos no se han ejecutado
        for folder_date in folder_dates:
            if folder_date not in executed_dates:
                index = folder_dates.index(folder_date)
                files_to_execute.append(folders_info[index])
        
        logger.info(f'status: ejecutando - files_to_execute: {files_to_execute}')
                        
        if not files_to_execute:
            
            # Agregar los archivos a ejecutar en los parametros de ejecución
            param['files_to_execute'] = files_to_execute
            
            ##### ejecución del proceso
            execution(logger,instance_id,param)
            
            return logger.info('status: ejecutando - No hay archivos para ejecutar')
        else:
            logger.info(f"status: ejecutando - Realizando las ejecucion de las fechas nuevas")
            
            # Agregar los archivos a ejecutar en los parametros de ejecución
            param['files_to_execute'] = files_to_execute
            
            ##### ejecución del proceso
            execution(logger,instance_id,param)
            
    return "Ejecución finalizada"