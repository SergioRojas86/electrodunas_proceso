import boto3
import json
import csv
import io
from datetime import datetime
import time

s3 = boto3.client('s3')

def read_csv_files_log_s3(bucket_name, file_name):

    # Obtener el objeto CSV desde S3
    response_log = s3.get_object(Bucket=bucket_name, Key=file_name)
    csv_content = response_log['Body'].read().decode('utf-8')

    # Leer el contenido CSV usando la biblioteca csv
    csv_buffer = io.StringIO(csv_content)
    reader = csv.reader(csv_buffer)

    # Saltar el encabezado
    next(reader)

    # Leer todos los registros de la columna y guardarlos en una lista
    list_executed_files = [(row[0],row[1],row[2]) for row in reader]
    
    return list_executed_files

    
def list_objects_source_s3(logger, cleaning_bucket, clean_folder, execution_date):
    s3 = boto3.client('s3')

    # Listar objetos en el bucket por directorios
    response_source = s3.list_objects_v2(Bucket=cleaning_bucket, Prefix=clean_folder+'/', Delimiter='/')
    
    if 'CommonPrefixes' not in response_source:
        logger.info(f"status: ejecutando - No hay archivos en el bucket {cleaning_bucket} para procesar")
        return

    folders_info = []
    for prefix in response_source['CommonPrefixes']:
        folder_name = prefix['Prefix']
        
        # Listar objetos dentro de la carpeta
        response_objects = s3.list_objects_v2(Bucket=cleaning_bucket, Prefix=folder_name)
        
        # Comprobar si hay objetos en la carpeta
        if 'Contents' in response_objects:
            # Obtener la fecha máxima de modificación de los objetos dentro de la carpeta
            max_date_uploading = max(obj['LastModified'] for obj in response_objects['Contents'])
            max_date_uploading_f = max_date_uploading.strftime("%Y-%m-%d %H:%M:%S")
            
            folders_info.append((folder_name.split('/')[1], max_date_uploading_f, execution_date))
        else:
            logger.info(f"status: ejecutando - No hay archivos en la carpeta {folder_name} para procesar")
    
    logger.info(f"status: ejecutando - Folders: {folders_info}")
    return folders_info