from datetime import datetime
import time
from src.read_and_list_s3 import list_objects_source_s3
from src.execution import execution, execution_process
from src.utils import remove_confirm
from src.arrange_data import check_economic_filed_file, arrange_folder
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

def lambda_handler(event, context):
    #time.sleep(60)
    # Variables de uso para el proceso
    instance_id = 'i-0cc132efa9018072d'
    files_to_execute = []
    log_file = "log_executed_files.csv"
    source_bucket = "electrodunas-data"
    cleaning_bucket = "electrodunas-clean-data"
    backup_bucket = 'electrodunas-backup-data'
    log_bucket = "electrodunas-log-files"
    clean_folder = "clean"
    stage_folder = "stage"
    current_date = datetime.now()
    execution_date = current_date.strftime("%Y-%m-%d %H:%M:%S")
    
    logger.info('status: ejecutando - mensaje: inicia proceso electrodunas')
    # Revisar existencia del catalogo de sector economico
    flag = check_economic_filed_file(logger,source_bucket,cleaning_bucket,clean_folder)
    
    if flag == 0:
        logger.info('status: terminado - mensaje: no existe el catalogo de sector economico')
        remove_confirm(logger,source_bucket)
        return 
    else:
        # Organizar la data suministrada por año
        arrange_folder(logger,backup_bucket,source_bucket,cleaning_bucket,clean_folder,execution_date)
    
        folders_info=list_objects_source_s3(logger,cleaning_bucket,clean_folder,execution_date)
        execution_process(logger,instance_id,folders_info,log_bucket,log_file,
                            cleaning_bucket,clean_folder,stage_folder)
        remove_confirm(logger,source_bucket)
        logger.info('status: Finalizó - mensaje: finaliza proceso electrodunas')